"""Perintah operasi bertanda tangan ML-DSA + mekanisme anti-replay."""
import secrets
import time
import uuid

from .crypto import CTX_COMMAND, Identity, Registry, b64d, b64e, canonical, sign, verify

FRESHNESS_WINDOW = 120  # detik; perintah lebih tua dari ini ditolak
AUTHORIZED_ROLES = {"KOMANDO"}


def create_command(sender: Identity, recipient: str, seq: int, order: dict, ts=None) -> dict:
    body = {"type": "COMMAND", "id": uuid.uuid4().hex[:12], "from": sender.name,
            "to": recipient, "seq": seq, "ts": int(ts if ts is not None else time.time()),
            "nonce": secrets.token_hex(16), "order": order}
    return {"body": body, "sig": b64e(sign(sender.sig_sk, canonical(body), CTX_COMMAND))}


class ReplayGuard:
    """Tolak nonce yang pernah dipakai dan nomor urut yang tidak naik."""

    def __init__(self):
        self.last_seq = {}
        self.seen = {}  # nonce -> ts

    def _purge(self, now):
        for n, ts in list(self.seen.items()):
            if now - ts > FRESHNESS_WINDOW * 2:
                del self.seen[n]

    def check(self, body, now):
        self._purge(now)
        if body["nonce"] in self.seen:
            return False, "Nonce sudah pernah dipakai (replay)"
        if body["seq"] <= self.last_seq.get(body["from"], 0):
            return False, f"Nomor urut {body['seq']} ≤ terakhir {self.last_seq[body['from']]}"
        return True, "Nonce baru & nomor urut naik"

    def commit(self, body):
        self.seen[body["nonce"]] = body["ts"]
        self.last_seq[body["from"]] = body["seq"]


def verify_command(env: dict, me: Identity, registry: Registry, guard: ReplayGuard, now=None):
    """Kembalikan (diterima, daftar_cek). Berhenti di cek pertama yang gagal."""
    now = now or time.time()
    body, checks = env["body"], []

    def add(name, ok, detail):
        checks.append({"check": name, "ok": ok, "detail": detail})
        return ok

    sender = registry.get(body.get("from"))
    if not add("Identitas pengirim terdaftar", sender is not None,
               body.get("from") if sender else f"'{body.get('from')}' tidak dikenal"):
        return False, checks
    if not add("Pengirim berwenang memberi perintah", sender["role"] in AUTHORIZED_ROLES,
               f"peran {sender['role']}"):
        return False, checks
    ok = verify(sender["sig_pk"], canonical(body), b64d(env["sig"]), CTX_COMMAND)
    if not add("Tanda tangan ML-DSA-65 valid", ok,
               "isi utuh & benar dari pengirim" if ok else "palsu / isi diubah"):
        return False, checks
    if not add("Ditujukan ke satuan ini", body["to"] == me.name, f"tujuan {body['to']}"):
        return False, checks
    age = now - body["ts"]
    if not add("Perintah masih segar", -5 <= age <= FRESHNESS_WINDOW,
               f"umur {int(age)} dtk (maks {FRESHNESS_WINDOW})"):
        return False, checks
    ok, detail = guard.check(body, now)
    if not add("Anti-replay", ok, detail):
        return False, checks
    guard.commit(body)
    return True, checks
