"""Primitif kriptografi PASOPATI.

- ML-DSA-65 (FIPS 204)  : tanda tangan digital (perintah, transaksi, handshake)
- ML-KEM-768 (FIPS 203) : enkapsulasi kunci pasca-kuantum
- X25519 (ECDH)         : kunci klasik, digabung dengan ML-KEM (hybrid)
- HKDF-SHA384           : penurunan kunci sesi dari dua shared secret
- AES-256-GCM           : enkripsi + integritas pesan
"""
import base64
import hashlib
import json
import os
import secrets
import time

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from dilithium_py.ml_dsa import ML_DSA_65
from kyber_py.ml_kem import ML_KEM_768

CTX_HANDSHAKE = b"QS-HANDSHAKE-v1"
CTX_COMMAND = b"QS-COMMAND-v1"
CTX_LOGISTICS = b"QS-LOGISTICS-v1"
HANDSHAKE_WINDOW = 120  # detik


def b64e(b: bytes) -> str:
    return base64.b64encode(b).decode()


def b64d(s: str) -> bytes:
    return base64.b64decode(s)


def canonical(obj) -> bytes:
    """Serialisasi JSON deterministik agar tanda tangan konsisten."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def fingerprint(pk: bytes) -> str:
    h = hashlib.sha256(pk).hexdigest()[:16].upper()
    return ":".join(h[i:i + 4] for i in range(0, 16, 4))


def sign(sk: bytes, msg: bytes, ctx: bytes) -> bytes:
    return ML_DSA_65.sign(sk, msg, ctx=ctx)


def verify(pk: bytes, msg: bytes, sig: bytes, ctx: bytes) -> bool:
    try:
        return ML_DSA_65.verify(pk, msg, sig, ctx=ctx)
    except Exception:
        return False


class Identity:
    """Identitas sebuah node: kunci tanda tangan + kunci pertukaran kunci."""

    def __init__(self, name, role, sig_pk, sig_sk, kem_ek, kem_dk, x_sk_raw):
        self.name, self.role = name, role
        self.sig_pk, self.sig_sk = sig_pk, sig_sk
        self.kem_ek, self.kem_dk = kem_ek, kem_dk
        self.x_sk = X25519PrivateKey.from_private_bytes(x_sk_raw)
        self.x_pub = self.x_sk.public_key().public_bytes(
            serialization.Encoding.Raw, serialization.PublicFormat.Raw)

    @classmethod
    def generate(cls, name, role):
        sig_pk, sig_sk = ML_DSA_65.keygen()
        kem_ek, kem_dk = ML_KEM_768.keygen()
        return cls(name, role, sig_pk, sig_sk, kem_ek, kem_dk, os.urandom(32))

    def public(self) -> dict:
        return {"name": self.name, "role": self.role, "sig_pk": self.sig_pk,
                "kem_ek": self.kem_ek, "x_pub": self.x_pub}

    def to_json(self) -> dict:
        x_raw = self.x_sk.private_bytes(serialization.Encoding.Raw,
                                        serialization.PrivateFormat.Raw,
                                        serialization.NoEncryption())
        return {"name": self.name, "role": self.role,
                "sig_pk": b64e(self.sig_pk), "sig_sk": b64e(self.sig_sk),
                "kem_ek": b64e(self.kem_ek), "kem_dk": b64e(self.kem_dk),
                "x_sk": b64e(x_raw)}

    @classmethod
    def from_json(cls, d):
        return cls(d["name"], d["role"], b64d(d["sig_pk"]), b64d(d["sig_sk"]),
                   b64d(d["kem_ek"]), b64d(d["kem_dk"]), b64d(d["x_sk"]))


class Registry:
    """Daftar kunci publik node tepercaya (pengganti PKI sederhana)."""

    def __init__(self):
        self._nodes = {}

    def add(self, pub: dict):
        self._nodes[pub["name"]] = pub

    def get(self, name):
        return self._nodes.get(name)

    def all(self):
        return list(self._nodes.values())


def _derive_key(ss_ecdh: bytes, ss_kem: bytes, transcript: bytes) -> bytes:
    return HKDF(algorithm=hashes.SHA384(), length=32, salt=b"PASOPATI-hybrid-v1",
                info=hashlib.sha384(transcript).digest()).derive(ss_ecdh + ss_kem)


class Session:
    """Kanal terenkripsi AES-256-GCM antara dua node."""

    def __init__(self, key: bytes, sid: str, local: str, peer: str):
        self.key, self.sid, self.local, self.peer = key, sid, local, peer
        self.aead = AESGCM(key)

    def encrypt(self, plaintext: bytes) -> dict:
        nonce = os.urandom(12)
        aad = canonical({"sid": self.sid, "from": self.local, "to": self.peer})
        return {"sid": self.sid, "from": self.local, "to": self.peer,
                "nonce": b64e(nonce), "ct": b64e(self.aead.encrypt(nonce, plaintext, aad))}

    def decrypt(self, packet: dict) -> bytes:
        """Lempar InvalidTag bila paket diubah sedikit pun."""
        aad = canonical({"sid": packet["sid"], "from": packet["from"], "to": packet["to"]})
        return self.aead.decrypt(b64d(packet["nonce"]), b64d(packet["ct"]), aad)


def handshake_initiate(me: Identity, peer_pub: dict):
    """Inisiator: X25519 ephemeral + ML-KEM encaps, ditandatangani ML-DSA."""
    t0 = time.perf_counter()
    eph = X25519PrivateKey.generate()
    eph_pub = eph.public_key().public_bytes(serialization.Encoding.Raw,
                                            serialization.PublicFormat.Raw)
    ss_ecdh = eph.exchange(X25519PublicKey.from_public_bytes(peer_pub["x_pub"]))
    ss_kem, kem_ct = ML_KEM_768.encaps(peer_pub["kem_ek"])
    hs = {"from": me.name, "to": peer_pub["name"], "eph_pub": b64e(eph_pub),
          "kem_ct": b64e(kem_ct), "ts": int(time.time()), "nonce": secrets.token_hex(16)}
    transcript = canonical(hs)
    sig = sign(me.sig_sk, transcript, CTX_HANDSHAKE)
    key = _derive_key(ss_ecdh, ss_kem, transcript)
    sid = hashlib.sha256(transcript).hexdigest()[:16]
    stats = {"ms": round((time.perf_counter() - t0) * 1000, 1),
             "kem_ct_bytes": len(kem_ct), "eph_pub_bytes": len(eph_pub), "sig_bytes": len(sig)}
    return {"hs": hs, "sig": b64e(sig)}, Session(key, sid, me.name, peer_pub["name"]), stats


def handshake_respond(me: Identity, msg: dict, registry: Registry):
    """Responder: verifikasi tanda tangan inisiator, lalu turunkan kunci sesi."""
    hs = msg["hs"]
    sender = registry.get(hs["from"])
    if sender is None:
        raise ValueError("Inisiator tidak terdaftar")
    if hs["to"] != me.name:
        raise ValueError("Handshake bukan untuk node ini")
    if abs(time.time() - hs["ts"]) > HANDSHAKE_WINDOW:
        raise ValueError("Handshake kedaluwarsa")
    transcript = canonical(hs)
    if not verify(sender["sig_pk"], transcript, b64d(msg["sig"]), CTX_HANDSHAKE):
        raise ValueError("Tanda tangan handshake tidak valid")
    ss_ecdh = me.x_sk.exchange(X25519PublicKey.from_public_bytes(b64d(hs["eph_pub"])))
    ss_kem = ML_KEM_768.decaps(me.kem_dk, b64d(hs["kem_ct"]))
    key = _derive_key(ss_ecdh, ss_kem, transcript)
    sid = hashlib.sha256(transcript).hexdigest()[:16]
    return Session(key, sid, me.name, hs["from"])


__all__ = ["Identity", "Registry", "Session", "handshake_initiate", "handshake_respond",
           "sign", "verify", "canonical", "fingerprint", "b64e", "b64d", "InvalidTag",
           "CTX_COMMAND", "CTX_LOGISTICS"]
