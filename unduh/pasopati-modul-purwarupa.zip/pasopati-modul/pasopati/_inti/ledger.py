"""Ledger logistik: tiap transaksi ditandatangani ML-DSA dan dirantai hash SHA-256."""
import hashlib
import sqlite3
import time
import uuid

from .crypto import CTX_LOGISTICS, Identity, Registry, b64d, b64e, canonical, sign, verify

GENESIS = "0" * 96
AUTHORIZED_ROLES = {"LOGISTIK"}
JENIS = ["Amunisi", "Peralatan", "Kendaraan", "Personel"]


def create_tx(node: Identity, jenis, item, qty, dari, ke, ts=None) -> dict:
    body = {"type": "LOGISTICS_TX", "id": uuid.uuid4().hex[:12], "signer": node.name,
            "jenis": jenis, "item": item, "qty": int(qty), "dari": dari, "ke": ke,
            "ts": int(ts if ts is not None else time.time())}
    return {"body": body, "sig": b64e(sign(node.sig_sk, canonical(body), CTX_LOGISTICS))}


def _hash(prev, body_json, sig):
    return hashlib.sha384((prev + body_json + sig).encode()).hexdigest()


class Ledger:
    def __init__(self, path, registry: Registry):
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.registry = registry
        self.db.execute("""CREATE TABLE IF NOT EXISTS tx (
            idx INTEGER PRIMARY KEY, body TEXT, sig TEXT, prev_hash TEXT, hash TEXT)""")
        self.db.commit()

    def _check_signature(self, body, sig):
        signer = self.registry.get(body.get("signer"))
        if signer is None:
            return False, "penanda tangan tidak terdaftar"
        if signer["role"] not in AUTHORIZED_ROLES:
            return False, f"peran {signer['role']} tidak berwenang"
        if not verify(signer["sig_pk"], canonical(body), b64d(sig), CTX_LOGISTICS):
            return False, "tanda tangan ML-DSA tidak valid"
        return True, "tanda tangan valid"

    def append(self, env: dict):
        ok, reason = self._check_signature(env["body"], env["sig"])
        if not ok:
            return False, reason
        row = self.db.execute("SELECT hash FROM tx ORDER BY idx DESC LIMIT 1").fetchone()
        prev = row[0] if row else GENESIS
        body_json = canonical(env["body"]).decode()
        h = _hash(prev, body_json, env["sig"])
        self.db.execute("INSERT INTO tx (body, sig, prev_hash, hash) VALUES (?,?,?,?)",
                        (body_json, env["sig"], prev, h))
        self.db.commit()
        return True, h

    def rows(self):
        import json
        out = []
        for idx, body, sig, prev, h in self.db.execute(
                "SELECT idx, body, sig, prev_hash, hash FROM tx ORDER BY idx"):
            out.append({"idx": idx, "body": json.loads(body), "sig": sig, "prev": prev, "hash": h})
        return out

    def verify_chain(self):
        """Periksa ulang seluruh rantai: hash, tautan, dan tanda tangan."""
        import json
        results, expected_prev = [], GENESIS
        for idx, body_json, sig, prev, h in self.db.execute(
                "SELECT idx, body, sig, prev_hash, hash FROM tx ORDER BY idx"):
            problems = []
            if prev != expected_prev:
                problems.append("rantai putus (prev_hash tidak cocok)")
            if _hash(prev, body_json, sig) != h:
                problems.append("hash tidak cocok (isi diubah)")
            try:
                ok, reason = self._check_signature(json.loads(body_json), sig)
            except Exception:
                ok, reason = False, "data rusak"
            if not ok:
                problems.append(reason)
            results.append({"idx": idx, "ok": not problems, "problems": problems})
            expected_prev = h
        return {"ok": all(r["ok"] for r in results), "rows": results}

    def tamper(self, idx, new_qty, rehash=False):
        """SIMULASI SERANGAN: ubah langsung di database (mis. orang dalam)."""
        import json
        row = self.db.execute("SELECT body, sig, prev_hash FROM tx WHERE idx=?", (idx,)).fetchone()
        if not row:
            return False
        body = json.loads(row[0])
        body["qty"] = int(new_qty)
        body_json = canonical(body).decode()
        if rehash:  # penyerang pintar: hitung ulang hash seluruh rantai
            self.db.execute("UPDATE tx SET body=? WHERE idx=?", (body_json, idx))
            prev = row[2]
            for i, b, s in self.db.execute(
                    "SELECT idx, body, sig FROM tx WHERE idx>=? ORDER BY idx", (idx,)).fetchall():
                h = _hash(prev, b, s)
                self.db.execute("UPDATE tx SET prev_hash=?, hash=? WHERE idx=?", (prev, h, i))
                prev = h
        else:
            self.db.execute("UPDATE tx SET body=? WHERE idx=?", (body_json, idx))
        self.db.commit()
        return True

    def reset(self):
        self.db.execute("DELETE FROM tx")
        self.db.commit()
