"""PASOPATI SDK (versi purwarupa untuk evaluasi).

Perlindungan Autentikasi Sandi Operasi Pasca-kuantum Anti Tiruan & Intersepsi.

Tiga lapis pelindung:
  1. Paraf digital perintah (ML-DSA-65, FIPS 204) + anti kiriman ulang
  2. Amplop tersegel dua lapis (X25519 + ML-KEM-768 -> HKDF-SHA384 -> AES-256-GCM)
  3. Register logistik berparaf dan berantai (ML-DSA-65 + SHA-256)

Contoh singkat:
    from pasopati import Identitas, Registri, Penerima, paraf_perintah
    puskom = Identitas.buat("PUSKOM", "KOMANDO")
    alfa = Identitas.buat("SATUAN-ALFA", "SATUAN")
    registri = Registri(puskom, alfa)
    perintah = paraf_perintah(puskom, "SATUAN-ALFA", {"operasi": "Patroli Sektor 7"}, nomor_urut=1)
    print(Penerima(alfa, registri).periksa(perintah))   # DITERIMA

PERINGATAN: purwarupa, bukan untuk operasi nyata. Pustaka sandi murni Python
belum constant-time dan kunci privat belum disimpan di perangkat aman (HSM).
"""
import json

from ._inti.command import ReplayGuard, create_command, verify_command
from ._inti.crypto import Identity, InvalidTag, Registry, canonical, handshake_initiate, handshake_respond
from ._inti.ledger import JENIS, Ledger, create_tx

__version__ = "0.1.0-purwarupa"
__all__ = ["Identitas", "Registri", "Penerima", "Hasil", "paraf_perintah", "buka_kanal",
           "KanalAman", "RegisterLogistik", "catatan_logistik", "JENIS"]


class Identitas:
    """Kunci paraf (ML-DSA-65) dan kunci tukar (ML-KEM-768 + X25519) milik satu node."""

    @staticmethod
    def buat(nama: str, peran: str) -> Identity:
        """peran: 'KOMANDO', 'SATUAN', 'LOGISTIK', atau 'SERVER'."""
        return Identity.generate(nama, peran)

    @staticmethod
    def simpan(identitas: Identity, path: str):
        with open(path, "w") as f:
            json.dump(identitas.to_json(), f)

    @staticmethod
    def muat(path: str) -> Identity:
        with open(path) as f:
            return Identity.from_json(json.load(f))


class Registri(Registry):
    """Daftar kunci publik node tepercaya."""

    def __init__(self, *identitas):
        super().__init__()
        for i in identitas:
            self.daftarkan(i)

    def daftarkan(self, identitas):
        self.add(identitas.public() if isinstance(identitas, Identity) else identitas)


class Hasil:
    def __init__(self, diterima, cek):
        self.diterima, self.cek = diterima, cek

    def __bool__(self):
        return self.diterima

    def __repr__(self):
        baris = [("DITERIMA" if self.diterima else "DITOLAK")]
        baris += [f"  {'✔' if c['ok'] else '✘'} {c['check']} — {c['detail']}" for c in self.cek]
        return "\n".join(baris)


def paraf_perintah(pengirim: Identity, tujuan: str, perintah: dict, nomor_urut: int) -> dict:
    """Bungkus dan paraf perintah. Nomor urut harus selalu naik per pengirim."""
    return create_command(pengirim, tujuan, nomor_urut, perintah)


class Penerima:
    """Dipasang di satuan: memeriksa setiap perintah yang masuk."""

    def __init__(self, identitas: Identity, registri: Registry):
        self.identitas, self.registri, self.penjaga = identitas, registri, ReplayGuard()

    def periksa(self, amplop: dict) -> Hasil:
        ok, cek = verify_command(amplop, self.identitas, self.registri, self.penjaga)
        return Hasil(ok, cek)


class KanalAman:
    """Satu sisi kanal terenkripsi; dibuat lewat buka_kanal()."""

    def __init__(self, sesi):
        self._sesi = sesi
        self.id_sesi = sesi.sid

    def segel(self, data) -> dict:
        if not isinstance(data, (bytes, bytearray)):
            data = canonical(data)
        return self._sesi.encrypt(bytes(data))

    def buka(self, paket: dict) -> bytes:
        """Melempar InvalidTag jika paket diubah di jalan."""
        return self._sesi.decrypt(paket)


def buka_kanal(pengirim: Identity, penerima: Identity, registri: Registry):
    """Handshake hibrida bertanda tangan. Mengembalikan (kanal_pengirim, kanal_penerima)."""
    pesan, sesi_a, _ = handshake_initiate(pengirim, registri.get(penerima.name))
    sesi_b = handshake_respond(penerima, pesan, registri)
    return KanalAman(sesi_a), KanalAman(sesi_b)


def catatan_logistik(node: Identity, jenis, barang, jumlah, dari, ke) -> dict:
    """Buat catatan logistik berparaf. jenis: Amunisi, Peralatan, Kendaraan, Personel."""
    return create_tx(node, jenis, barang, jumlah, dari, ke)


class RegisterLogistik(Ledger):
    """Register (SQLite) yang hanya menerima catatan berparaf dari node logistik terdaftar."""

    def catat(self, catatan):
        return self.append(catatan)

    def audit(self):
        return self.verify_chain()
