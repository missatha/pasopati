# Modul PASOPATI (versi purwarupa)

**P**erlindungan **A**utentikasi **S**andi **O**perasi **P**asca-kuantum **A**nti **T**iruan & **I**ntersepsi

> ⚠️ Versi purwarupa untuk evaluasi Kartika Cyber Hackathon 2026. Bukan untuk operasi nyata.
> Modul sandi militer sungguhan didistribusikan secara terkendali, bukan diunduh bebas.

## Pasang
```
pip install -r requirements.txt
python contoh.py
```

## Pakai
```python
from pasopati import Identitas, Registri, Penerima, paraf_perintah

puskom = Identitas.buat("PUSKOM", "KOMANDO")
alfa = Identitas.buat("SATUAN-ALFA", "SATUAN")
registri = Registri(puskom, alfa)

perintah = paraf_perintah(puskom, "SATUAN-ALFA", {"operasi": "Patroli Sektor 7"}, nomor_urut=1)
print(Penerima(alfa, registri).periksa(perintah))   # DITERIMA
```

| Fungsi | Kegunaan |
|---|---|
| `Identitas.buat(nama, peran)` | Membuat kunci paraf ML-DSA-65 dan kunci tukar ML-KEM-768 + X25519 |
| `Registri(...)` | Daftar node tepercaya |
| `paraf_perintah(...)` | Memaraf perintah dengan nomor urut, waktu, dan nonce |
| `Penerima(...).periksa(...)` | 6 pemeriksaan: identitas, wewenang, paraf, tujuan, kesegaran, anti kiriman ulang |
| `buka_kanal(a, b, registri)` | Kanal hibrida; `.segel()` dan `.buka()` memakai AES-256-GCM |
| `RegisterLogistik(path, registri)` | `.catat()` dan `.audit()` catatan logistik berantai |
