"""Contoh pemakaian modul PASOPATI. Jalankan: python contoh.py"""
import json, os, tempfile

from pasopati import (Identitas, Registri, Penerima, RegisterLogistik, buka_kanal,
                      catatan_logistik, paraf_perintah)

print("Membuat identitas pasca-kuantum…")
puskom = Identitas.buat("PUSKOM", "KOMANDO")
alfa = Identitas.buat("SATUAN-ALFA", "SATUAN")
gudang = Identitas.buat("GUDANG-PUSAT", "LOGISTIK")
penyusup = Identitas.buat("PUSKOM", "KOMANDO")        # mengaku PUSKOM, kunci berbeda
registri = Registri(puskom, alfa, gudang)

print("\n1) Perintah sah")
kanal_puskom, kanal_alfa = buka_kanal(puskom, alfa, registri)
perintah = paraf_perintah(puskom, "SATUAN-ALFA", {"operasi": "Patroli Sektor 7"}, nomor_urut=1)
paket = kanal_puskom.segel(perintah)                     # amplop tersegel dua lapis
diterima = json.loads(kanal_alfa.buka(paket))
penerima = Penerima(alfa, registri)
print(penerima.periksa(diterima))

print("\n2) Perintah yang sama dikirim ulang")
print(penerima.periksa(diterima))

print("\n3) Penyusup mengaku Pusat Komando")
palsu = paraf_perintah(penyusup, "SATUAN-ALFA", {"operasi": "Tarik mundur"}, nomor_urut=2)
print(penerima.periksa(palsu))

print("\n4) Register logistik")
db = os.path.join(tempfile.mkdtemp(), "register.db")
register = RegisterLogistik(db, registri)
register.catat(catatan_logistik(gudang, "Amunisi", "Munisi 5.56 mm (peti)", 120, "Gudang Pusat", "Satuan Alfa"))
print("Audit:", "UTUH" if register.audit()["ok"] else "RUSAK")
register.tamper(1, 12)                                  # simulasi orang dalam
print("Audit setelah diubah:", register.audit())
